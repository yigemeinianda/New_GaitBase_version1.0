1.We have provided the resnet-FRN-TLU.py file, which includes a simple method for building FRN layers and TLU functions, making it easier for you to replace BN layers.

2.Please set the specific experimental results according to your device performance and requirements.

3.The processing method of the dataset is the same as OpenGait, please refer to for details:{
    	Fan, Chao and Liang, Junhao and Shen, Chuanfu and Hou, Saihui and Huang, Yongzhen and Yu, Shiqi. OpenGait: Revisiting Gait Recognition Towards Better Practicality.
        In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR2023), pages 9707-9716}
        https://github.com/ShiqiYu/OpenGait#readme

