#////////////////////////////////////////新增FRN层+TLU层///////////////////////////////////////////
class FRN(nn.Module):
    def __init__(self, num_features, eps = 1e-6):
        super(FRN,self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.gamma = nn.Parameter(torch.Tensor(1, num_features, 1, 1))
        self.beta = nn.Parameter(torch.Tensor(1, num_features, 1, 1))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.ones_(self.gamma)
        nn.init.zeros_(self.beta)

    def forward(self, x):
        #nu2 = x.var(dim=[2,3],keepdim=True)  #计算输入x的方差
        nu2 = x.pow(2).mean(dim=[2, 3], keepdim=True)  
        x = x / torch.sqrt(nu2 + self.eps)
        #x = x.div_(torch.sqrt(nu2 + self.eps))
        return self.gamma * x + self.beta