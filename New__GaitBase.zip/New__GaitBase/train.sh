# # ******************************************************* For CASIA-B ******************************************************************
# # Baseline
#CUDA_VISIBLE_DEVICES=0   torchrun   opengait/main.py --cfgs ./configs/gaitbase/gaitbase_da_casiab.yaml --phase train

# # GaitSet
# CUDA_VISIBLE_DEVICES=0,1 python -m torch.distributed.launch --nproc_per_node=2 opengait/main.py --cfgs ./configs/gaitset/gaitset.yaml --phase train


 

# #*******************************************************For Gait3D *********************************************************************
# # Baseline
CUDA_VISIBLE_DEVICES=0   torchrun   opengait/main.py --cfgs ./configs/gaitbase/gaitbase_da_gait3d.yaml --phase train
 